﻿DWORD WINAPI shader1(LPVOID lpvd) 
{
	srand(time(NULL));
	int i = 0;
	while (true) {
		HDC hdc = GetDC(0), hcdc = CreateCompatibleDC(hdc);
		int w = GetSystemMetrics(0), h = GetSystemMetrics(1), rndsize = 1 + rand() % (h / 2);
		BITMAPINFO bmpi = { 0 };
		bmpi.bmiHeader = { sizeof(bmpi), w, h, 1, 32, BI_RGB };
		RGBQUAD* rgbquad = NULL; HSL hslcolor;
		HBITMAP hBitmap = CreateDIBSection(hdc, &bmpi, DIB_RGB_COLORS, (void**)&rgbquad, NULL, 0);
		SelectObject(hcdc, hBitmap);
		BitBlt(hcdc, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
		for (int xxx = 0; xxx < w; xxx++) {
			StretchBlt(hcdc, xxx, -2 + rand() % 5, 1, h, hcdc, xxx, 0, 1, h, NOTSRCCOPY);
		}
		for (int xxx = 0; xxx < w; xxx += rndsize) {
			StretchBlt(hcdc, xxx, -2 + rand() % 5, rndsize, h, hcdc, xxx, 0, rndsize, h, SRCPAINT);
		}
		for (int yyy = 0; yyy < h; yyy++) {
			StretchBlt(hcdc, -2 + rand() % 5, yyy, w, 1, hcdc, 0, yyy, w, 1, SRCINVERT);
		}
		for (int yyy = 0; yyy < h; yyy += rndsize) {
			StretchBlt(hcdc, -2 + rand() % 5, yyy, w, rndsize, hcdc, 0, yyy, w, rndsize, SRCAND);
		}
		RGBQUAD rgbquadCopy;
		for (int x = 0; x < w; x++) {
			for (int y = 0; y < h; y++) {
				int index = y * w + x;
				float fx = (9 * i) + ((9 * i) * (x / 32)) + (9 * i) + ((9 * i) * ((y + i) / 32));
				rgbquadCopy = rgbquad[index];
				hslcolor = Colors::rgb2hsl(rgbquadCopy);
				hslcolor.h = fmod(fx / 1000.f, 1.f);
				hslcolor.s = 1.f;
				hslcolor.l += 0.1f;
				rgbquad[index] = Colors::hsl2rgb(hslcolor);
			}
		}
		BitBlt(hdc, 0, 0, w, h, hcdc, 0, 0, NOTSRCERASE);
		ReleaseDC(0, hdc); ReleaseDC(0, hcdc);
		DeleteObject(hBitmap);
		DeleteDC(hcdc); DeleteDC(hdc);
		Sleep(1); i += 4;
	}
}
DWORD WINAPI screenrotate1(LPVOID lpParam) {
	HDC hdc = GetDC(0);
	int w = GetSystemMetrics(SM_CXSCREEN), h = GetSystemMetrics(SM_CYSCREEN);
	POINT wPt[3];
	wPt[0].x = w / 20;
	wPt[0].y = h / 20;
	wPt[1].x = w / 20 * 24;
	wPt[1].y = h / 20;
	wPt[2].x = w / 40;
	wPt[2].y = h / 40 * 42;
	for (;;) {
		PlgBlt(hdc, wPt, hdc, 0, 0, w, h, NULL, 0, 0);
		Sleep(50);
	}
}
DWORD WINAPI sinewavez(LPVOID lpParam) {
	HDC hdc = GetDC(0); HWND wnd = GetDesktopWindow();
	int sw = GetSystemMetrics(0), sh = GetSystemMetrics(1);
	double angle = 0;
	for (;;) {
		hdc = GetDC(0);
		for (float i = 0; i < sw + sh; i += 0.99f) {
			int a = sin(angle) * 20;
			BitBlt(hdc, 0, i, sw, 1, hdc, a, i, NOTSRCCOPY);
			BitBlt(hdc, i, 0, 1, sh, hdc, i, a, SRCINVERT);
			angle += PI / 40;
			DeleteObject(&a); DeleteObject(&i);
		}
		ReleaseDC(wnd, hdc);
		DeleteDC(hdc); DeleteObject(wnd); DeleteObject(&sw); DeleteObject(&sh); DeleteObject(&angle);
	}
}
DWORD WINAPI heptagon(LPVOID lpParam) //by pankoza, but i modified
{
	int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
	int signX = 1;
	int signY = 1;
	int incrementor = 10;
	int x = 10;
	int y = 10;

	while (1) {
		HDC hdc = GetDC(0);
		x += incrementor * signX;
		y += incrementor * signY;

		int centerX = x + 50;
		int centerY = y + 50;
		int radius = 90;

		POINT heptagonPoints[7];
		for (int i = 0; i < 7; ++i) {
			double angle = 4.0 * PI * i / 7;
			heptagonPoints[i].x = centerX + static_cast<int>(radius * cos(angle));
			heptagonPoints[i].y = centerY + static_cast<int>(radius * sin(angle));
		}

		HBRUSH brush = CreateSolidBrush(Hue(239));
		SelectObject(hdc, brush);
		Polygon(hdc, heptagonPoints, 7);

		if (centerY >= GetSystemMetrics(SM_CYSCREEN)) {
			signY = -1;
		}

		if (centerX >= GetSystemMetrics(SM_CXSCREEN)) {
			signX = -1;
		}

		if (centerY <= 0) {
			signY = 1;
		}

		if (centerX <= 0) {
			signX = 1;
		}

		Sleep(1);
		DeleteObject(brush);
		ReleaseDC(0, hdc);
	}
}
DWORD WINAPI shader2(LPVOID lpParam) {//by pankoza
	HDC hdcScreen = GetDC(0), hdcMem = CreateCompatibleDC(hdcScreen);
	INT w = GetSystemMetrics(0), h = GetSystemMetrics(1);
	BITMAPINFO bmi = { 0 };
	PRGBQUAD rgbScreen = { 0 };
	bmi.bmiHeader.biSize = sizeof(BITMAPINFO);
	bmi.bmiHeader.biBitCount = 32;
	bmi.bmiHeader.biPlanes = 1;
	bmi.bmiHeader.biWidth = w;
	bmi.bmiHeader.biHeight = h;
	HBITMAP hbmTemp = CreateDIBSection(hdcScreen, &bmi, NULL, (void**)&rgbScreen, NULL, NULL);
	SelectObject(hdcMem, hbmTemp);
	for (;;) {
		hdcScreen = GetDC(0);
		BitBlt(hdcMem, 0, 0, w, h, hdcScreen, 0, 0, SRCCOPY);
		for (INT i = 0; i < w * h; i++) {
			INT x = i % w, y = i / w;

			int cx = x - (w / 2);
			int cy = y - (h / 2);

			int zx = (cx * cx);
			int zy = (cy * cy);

			int di = 128.0 + i;

			int fx = di + (di * sin((zx + zy) / 32.0));
			rgbScreen[i].r *= fx + i;
     rgbScreen[i].g ^= x ^ y;
     rgbScreen[i].b += 20;
		}
		BitBlt(hdcScreen, 0, 0, w, h, hdcMem, 0, 0, SRCCOPY);
		ReleaseDC(NULL, hdcScreen); DeleteDC(hdcScreen);
	}
}
DWORD WINAPI shader3(LPVOID lpParam) {
	srand(time(NULL));
	BLENDFUNCTION blur = { AC_SRC_OVER, 0, 60, 0 }; 
	int xxx = 0;
	while (true) {
		int w = GetSystemMetrics(0); int h = GetSystemMetrics(1);
		HDC hdc = GetDC(0), hcdc = CreateCompatibleDC(hdc);
		BITMAPINFO bmi = { 0 }; PRGBQUAD rgbScreen = { 0 };
		bmi.bmiHeader = { sizeof(BITMAPINFOHEADER), w, h, 1, 32, BI_RGB };
		HBITMAP hBitmap = CreateDIBSection(hdc, &bmi, NULL, (void**)&rgbScreen, NULL, NULL);
		SelectObject(hcdc, hBitmap);
		for (int i = 0; i < w * h; i++) {
			int x = i % w, y = i / w, cxk = cbrt((float)(rgbScreen[i].r ^ rgbScreen[i].g ^ rgbScreen[i].b));
			rgbScreen[i].r = xxx + (x + cxk);
			rgbScreen[i].g = xxx + (x + cxk);
			rgbScreen[i].b = xxx + (y + cxk);
		}
		for (int bl = 0; bl < h; bl += 1) {
			StretchBlt(hcdc, -2 + rand() % 5, bl, w, 1, hcdc, 0, bl, w, 1, NOTSRCERASE);
		}
		AlphaBlend(hdc, 0, 0, w, h, hcdc, 0, 0, w, h, blur);
		ReleaseDC(0, hdc); ReleaseDC(0, hcdc);
		DeleteObject(hBitmap);
		DeleteDC(hcdc); DeleteDC(hdc);
		Sleep(10); 
		xxx += 10;
	}
}
DWORD WINAPI textoutz(LPVOID lpParam) {
	int x = GetSystemMetrics(0);
	int y = GetSystemMetrics(1);
	LPCSTR text = 0;
	LPCSTR text1 = 0;
	LPCSTR text2 = 0;
	LPCSTR text3 = 0;
	LPCSTR text4 = 0;
	LPCSTR text5 = 0;
	LPCSTR text6 = 0;
	while (1)
	{
		HDC hdc = GetDC(0);
		SetBkMode(hdc, 0);
		text = "Matějjjj.exe (NO SKIDDDDDD) Made By MazeIcon";
		text1 = "GOOOOOOOOOOD MALWAREEEEEEEEE";
		text2 = "NO SKIDDED, NO SKIDDDDDDDDERRRRRRRR...";
		text3 = "NOSKID NOSKID NO SKID NO SKIDDER NO SKID";
		text4 = "Get Out You Skidded Malware";
		text5 = "No Skidder Kicked Skid Malware";
		text6 = "No Skidded Kick Skidder";
		SetTextColor(hdc, Hue(239));
		HFONT font = CreateFontA(rand() % 100, rand() % 100, 0, 0, FW_THIN, 0, rand() % 1, 0, ANSI_CHARSET, 0, 0, 0, 0, "N17Pro3426Î̉²ÙÄăÂè");
		SelectObject(hdc, font);
		TextOutA(hdc, rand() % x, rand() % y, text, strlen(text));
		Sleep(10);
		TextOutA(hdc, rand() % x, rand() % y, text1, strlen(text1));
		Sleep(10);
		TextOutA(hdc, rand() % x, rand() % y, text2, strlen(text2));
		Sleep(10);
		TextOutA(hdc, rand() % x, rand() % y, text3, strlen(text3));
		Sleep(10);
		TextOutA(hdc, rand() % x, rand() % y, text4, strlen(text4));
		Sleep(10);
		TextOutA(hdc, rand() % x, rand() % y, text5, strlen(text5));
		Sleep(10);
		TextOutA(hdc, rand() % x, rand() % y, text6, strlen(text6));
		Sleep(10);
		DeleteObject(font);
		ReleaseDC(0, hdc);
	}
}
DWORD WINAPI shader4(LPVOID lpvd)
{
	HDC hdc = GetDC(NULL);
	HDC hdcCopy = CreateCompatibleDC(hdc);
	int w = GetSystemMetrics(0);
	int h = GetSystemMetrics(1);
	BITMAPINFO bmpi = { 0 };
	HBITMAP bmp;

	bmpi.bmiHeader.biSize = sizeof(bmpi);
	bmpi.bmiHeader.biWidth = w;
	bmpi.bmiHeader.biHeight = h;
	bmpi.bmiHeader.biPlanes = 1;
	bmpi.bmiHeader.biBitCount = 32;
	bmpi.bmiHeader.biCompression = BI_RGB;

	RGBQUAD* rgbquad = NULL;
	HSL hslcolor;

	bmp = CreateDIBSection(hdc, &bmpi, DIB_RGB_COLORS, (void**)&rgbquad, NULL, 0);
	SelectObject(hdcCopy, bmp);

	INT i = 0;

	while (1)
	{
		hdc = GetDC(NULL);
		StretchBlt(hdcCopy, 0, 0, w, h, hdc, 0, 0, w, h, SRCCOPY);

		RGBQUAD rgbquadCopy;

		for (int x = 0; x < w; x++)
		{
			for (int y = 0; y < h; y++)
			{
				int index = y * w + x;

				int fx = (int)(x * y);

				rgbquadCopy = rgbquad[index];

				hslcolor = Colors::rgb2hsl(rgbquadCopy);
				hslcolor.h = fmod(fx / 300.f + y / h * .1f, 3.f);

				rgbquad[index] = Colors::hsl2rgb(hslcolor);
			}
		}

		i++;
		StretchBlt(hdc, 0, 0, w, h, hdcCopy, 0, 0, w, h, NOTSRCCOPY);
		ReleaseDC(NULL, hdc); DeleteDC(hdc);
	}

	return 0x00;
}
DWORD WINAPI shader5(LPVOID lpParam) {
	while (1) {
		HDC hdc = GetDC(NULL);
		HDC hcdc = CreateCompatibleDC(hdc);
		int w = GetSystemMetrics(0);
		int h = GetSystemMetrics(1);
		BITMAPINFO bmpi = { 0 };
		BLENDFUNCTION blur;
		bmpi.bmiHeader.biSize = sizeof(bmpi);
		bmpi.bmiHeader.biWidth = w;
		bmpi.bmiHeader.biHeight = h;
		bmpi.bmiHeader.biPlanes = 1;
		bmpi.bmiHeader.biBitCount = 32;
		bmpi.bmiHeader.biCompression = BI_RGB;
		HBITMAP hBitmap = CreateDIBSection(hdc, &bmpi, 0, 0, NULL, 0);
		SelectObject(hcdc, hBitmap);
		blur.BlendOp = AC_SRC_OVER;
		blur.BlendFlags = 0;
		blur.AlphaFormat = 0;
		blur.SourceConstantAlpha = 10;
		BitBlt(hcdc, 0, 0, w, h, hdc, 0, 0, SRCINVERT);
		AlphaBlend(hdc, 0, 0, w, h, hcdc, 0, 0, w, h, blur);
		ReleaseDC(0, hdc);
		ReleaseDC(0, hcdc);
		DeleteObject(hBitmap);
		DeleteDC(hcdc);
		DeleteDC(hdc);
	}
}
DWORD WINAPI shader6(LPVOID lpParam) {
	double angle = 0;
	while (true) {
		int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
		HDC hdc = GetDC(0), hcdc = CreateCompatibleDC(hdc);
		HBITMAP hBitmap = CreateCompatibleBitmap(hdc, w, h);
		SelectObject(hcdc, hBitmap);
		BitBlt(hcdc, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
		for (float i = 0; i < w; i += 0.99f) {
			int a = cos(angle) * 40;
			BitBlt(hcdc, i, 0, 1, h, hcdc, i, a, SRCINVERT);
			angle += PI / 800;
		}
		for (float i = 0; i < h; i += 0.99f) {
			int a = cos(angle) * 40;
			BitBlt(hcdc, 0, i, w, 1, hcdc, a, i, NOTSRCERASE);
			angle += PI / 800;
		}
		BitBlt(hdc, 0, 0, w, h, hcdc, 0, 0, SRCPAINT);
		ReleaseDC(0, hdc); ReleaseDC(0, hcdc);
		DeleteObject(hBitmap);
		DeleteDC(hcdc); DeleteDC(hdc);
		Sleep(10);
	}
}
DWORD WINAPI shaking(LPVOID lpParam) {
	srand(time(NULL));
	while (1) {
		HDC hdc = GetDC(0);
		int w = GetSystemMetrics(0);
		int h = GetSystemMetrics(1);
		BitBlt(hdc, rand() % 90, rand() % 90, w, h, hdc, rand() % 90, rand() % 90, NOTSRCCOPY);
		ReleaseDC(NULL, hdc);
		Sleep(10);
	}
	return 0;
}
DWORD WINAPI shader7(LPVOID lpParam) {
	while (1) {
		HDC hdc = GetDC(NULL);
		HDC hcdc = CreateCompatibleDC(hdc);
		int w = GetSystemMetrics(0);
		int h = GetSystemMetrics(1);

		BITMAPINFO bmpi = { 0 };
		BLENDFUNCTION blur;

		bmpi.bmiHeader.biSize = sizeof(bmpi);
		bmpi.bmiHeader.biWidth = w;
		bmpi.bmiHeader.biHeight = h;
		bmpi.bmiHeader.biPlanes = 1;
		bmpi.bmiHeader.biBitCount = 32;
		bmpi.bmiHeader.biCompression = BI_RGB;

		HBITMAP hBitmap = CreateDIBSection(hdc, &bmpi, 0, 0, NULL, 0);
		SelectObject(hcdc, hBitmap);
		BitBlt(hcdc, 0, 0, w, h, hdc, 0, 0, SRCCOPY);
		blur.BlendOp = AC_SRC_OVER;
		blur.BlendFlags = 0;
		blur.AlphaFormat = 0;
		blur.SourceConstantAlpha = 20;
		StretchBlt(hcdc, rand() % 10, rand() % 10, w, h, hdc, rand() % 10, rand() % 10, w, h, NOTSRCERASE);
		AlphaBlend(hdc, 0, 0, w, h, hcdc, 0, 0, w, h, blur);
		ReleaseDC(NULL, hdc);
		ReleaseDC(NULL, hcdc);
		DeleteObject(hBitmap);
		DeleteDC(hcdc);
		DeleteDC(hdc);
		Sleep(10);
	}
	return 0;
}
DWORD WINAPI bbbbbbbbbbbbbbbbbbitblt(LPVOID lpParam) {
	int sw = GetSystemMetrics(0), sh = GetSystemMetrics(1);
	double moveangle = 0;
	while (1) {
		HDC hdc = GetDC(0);
		SelectObject(hdc, CreateSolidBrush(RGB(rand() % 333, rand() % 222, rand() % 111)));
		int rx = rand() % sw;
		int ry = rand() % sh;
		BitBlt(hdc, 20, ry, sw, 106, hdc, 0, ry, 0x1900ac010e);
		BitBlt(hdc, -20, ry, sw, -106, hdc, 0, ry, 0x1900ac010e);
		ReleaseDC(0, hdc);
		Sleep(10);
	}
}
DWORD WINAPI shader8(LPVOID lpParam) {
	int i = 0, xxx = 0;
	while (true) {
		HDC hdc = GetDC(0), hcdc = CreateCompatibleDC(hdc);
		int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
		BITMAPINFO bmpi = { 0 };
		bmpi.bmiHeader = { sizeof(BITMAPINFOHEADER), w, h, 1, 32, BI_RGB };
		RGBQUAD* rgbquad = NULL;
		HSL hslcolor; RGBQUAD rgbquadCopy;
		HBITMAP hBitmap = CreateDIBSection(hdc, &bmpi, DIB_RGB_COLORS, (void**)&rgbquad, NULL, 0);
		SelectObject(hcdc, hBitmap);
		for (int x = 0; x < w; x++) {
			for (int y = 0; y < h; y++) {
				int index = w * y + x;
				int fx = (int)(((x * xxx) | (y * xxx) | (x + xxx) * y));
				rgbquad[index].rgbRed = fx + i;
				rgbquad[index].rgbGreen = fx - 69;
				rgbquad[index].rgbBlue = fx + 5;
			}
		}
		BitBlt(hdc, 0, 0, w, h, hcdc, 0, 0, SRCCOPY);
		ReleaseDC(0, hdc); ReleaseDC(0, hcdc);
		DeleteObject(hBitmap);
		DeleteDC(hdc); DeleteDC(hcdc);
		Sleep(10); i++, xxx += 2;
	}
}
DWORD WINAPI shader9(LPVOID lpParam) {
	HDC hdc = GetDC(NULL);
	HDC hdcCopy = CreateCompatibleDC(hdc);
	int w = GetSystemMetrics(0);
	int h = GetSystemMetrics(1);
	BITMAPINFO bmpi = { 0 };
	BLENDFUNCTION blur;
	HBITMAP bmp;
	bmpi.bmiHeader.biSize = sizeof(bmpi);
	bmpi.bmiHeader.biWidth = w;
	bmpi.bmiHeader.biHeight = h;
	bmpi.bmiHeader.biPlanes = 1;
	bmpi.bmiHeader.biBitCount = 32;
	bmpi.bmiHeader.biCompression = BI_RGB;
	RGBQUAD* rgbquad = NULL;
	HSL hslcolor;
	bmp = CreateDIBSection(hdc, &bmpi, DIB_RGB_COLORS, (void**)&rgbquad, NULL, 0);
	SelectObject(hdcCopy, bmp);
	INT i = 0;
	while (1)
	{
		hdc = GetDC(NULL);
		StretchBlt(hdcCopy, 0, 0, w, h, hdc, 0, 0, w, h, SRCCOPY);
		RGBQUAD rgbquadCopy;
		for (int x = 0; x < w; x++)
		{
			for (int y = 0; y < h; y++)
			{
				int index = y * w + x;
				int fx = (int)((i ^ 4) + (i * 4) * (x * y));
				rgbquadCopy = rgbquad[index];
				hslcolor = Colors::rgb2hsl(rgbquadCopy);
				hslcolor.h = fmod(fx / 300.f + y / h * .1f + i / 1000.f, 1.f);
				hslcolor.s = 0.7f;
				hslcolor.l = 0.5f;
				rgbquad[index] = Colors::hsl2rgb(hslcolor);
			}
		}

		i++;
		blur.BlendOp = AC_SRC_OVER;
		blur.BlendFlags = 0;
		blur.AlphaFormat = 0;
		blur.SourceConstantAlpha = 80;
		AlphaBlend(hdc, 0, 0, w, h, hdcCopy, 0, 0, w, h, blur);
		ReleaseDC(NULL, hdc);
		DeleteDC(hdc);
	}
}
DWORD WINAPI finalpayloadnum1(LPVOID lpParam) {
	while (true) {
		int w = GetSystemMetrics(SM_CXSCREEN), h = GetSystemMetrics(SM_CYSCREEN);
		HDC hdc = GetDC(NULL);
		HDC hcdc = CreateCompatibleDC(hdc);
		HBITMAP hBitmap = CreateCompatibleBitmap(hdc, w, h);
		SelectObject(hcdc, hBitmap);
		BitBlt(hcdc, 0, 0, w, h, hdc, 0, 0, SRCERASE);
		BitBlt(hcdc, 0, 0, w / 10, h, hcdc, w / 10 * 9, 0, NOTSRCCOPY);
		BitBlt(hcdc, w / 10, 0, w / 10 * 9, h, hcdc, 0, 0, SRCAND);
		BitBlt(hdc, 0, 0, w, h, hcdc, 0, 0, SRCINVERT);
		ReleaseDC(NULL, hdc);
		ReleaseDC(NULL, hcdc);
		DeleteObject(hdc);
		DeleteObject(hcdc);
		DeleteObject(hBitmap);
		Sleep(10);
	}
}
DWORD WINAPI finalpayloadnum2(LPVOID lpParam) {
	HDC hdc = GetDC(0); HWND wnd = GetDesktopWindow();
	int sw = GetSystemMetrics(0), sh = GetSystemMetrics(1);
	double angle = 0;
	for (;;) {
		hdc = GetDC(0);
		for (float i = 0; i < sw + sh; i += 0.99f) {
			int a = tan(angle) * 50;
			BitBlt(hdc, 0, i, sw, 1, hdc, a, i, SRCINVERT);
			BitBlt(hdc, i, 0, 1, sh, hdc, i, a, NOTSRCERASE);
			angle += PI / 60;
			DeleteObject(&a); DeleteObject(&i);
		}
		if ((rand() % 100 + 1) % 67 == 0) InvalidateRect(0, 0, 0);
		ReleaseDC(wnd, hdc);
		DeleteDC(hdc); DeleteObject(wnd); DeleteObject(&sw); DeleteObject(&sh); DeleteObject(&angle);
	}
}
DWORD WINAPI finalpayloadnum3(LPVOID lpParam) {
	HDC hdc = GetDC(0); HWND wnd = GetDesktopWindow();
	int sw = GetSystemMetrics(0), sh = GetSystemMetrics(1);
	double angle = 0;
	for (;;) {
		hdc = GetDC(0);
		for (float i = 0; i < sw + sh; i += 0.99f) {
			int a = sin(angle) * 50;
			BitBlt(hdc, i, 0, 1, sh, hdc, i, a, NOTSRCERASE);
			angle += PI / 60;
			DeleteObject(&a); DeleteObject(&i);
		}
		if ((rand() % 100 + 1) % 67 == 0) InvalidateRect(0, 0, 0);
		ReleaseDC(wnd, hdc);
		DeleteDC(hdc); DeleteObject(wnd); DeleteObject(&sw); DeleteObject(&sh); DeleteObject(&angle);
	}
}
DWORD WINAPI finalpayloadnum4(LPVOID lpParam) {
	int move = 10;
	int w = GetSystemMetrics(0);
	int h = GetSystemMetrics(1);
	int go = 0;
	srand(time(NULL));
	while (true) {
		for (int y = 0; y < h; y++) {
			int sffasdfs = rand() % 50;
			if (sffasdfs > 25) {
				go = 1;
			}
			else {
				go = 0;
			}

			if (go == 1) {
				HDC hdc = GetDC(0);
				StretchBlt(hdc, -move, y, w, 1, hdc, 0, y, w, 1, NOTSRCCOPY);
				ReleaseDC(NULL, hdc);
			}
			else {
				HDC hdc = GetDC(0);
				StretchBlt(hdc, move, y, w, 1, hdc, 0, y, w, 1, SRCINVERT);
				ReleaseDC(NULL, hdc);
			}
		}
		Sleep(100);
	}
}